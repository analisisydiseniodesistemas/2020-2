#ifndef NODEHEADERDEF
#define NODEHEADERDEF

class Node
{
public:
   double coordinate;
};

#endif
//Code from Chapter12.tex line 566 save as Node.hpp
